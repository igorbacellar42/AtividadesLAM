import java.util.Scanner;

public class ExemploSaidaDados{
    public static void main(String[] args){
        System.out.print("Saida de Dados");
        System.out.println();
        String msg = "Uma mensagem";
        System.out.println(msg);
        System.out.printf("Metodo similar ao printf do C\n");
        int val = 42;
        System.out.printf("Pode-se incluir variaveis: %d\n", val);    
    }	
}
