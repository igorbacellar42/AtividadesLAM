import java.util.Scanner;

public class ExemploAlo{
    public static void main(String[] args){
        char option;
        option = 'c';
        
        int x = 42;

        double f = -43.5342;

        System.out.println("Alo Mundo");    
    }	
}
